﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PayrollSharedLibrary
{
    public abstract class BaseEmployee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal BasicPay { get; set; }
        public decimal Allowances { get; set; }

        public virtual decimal CalculateSalary()
        {
            return BasicPay + Allowances;
        }
    }

    public class Manager : BaseEmployee
    {
        public decimal Bonus { get; set; }
        public override decimal CalculateSalary()
        {
            return base.CalculateSalary() + Bonus;
        }
    }

    public class Developer : BaseEmployee { }

    public class Intern : BaseEmployee
    {
        public decimal Deduction { get; set; }
        public override decimal CalculateSalary()
        {
            return base.CalculateSalary() - Deduction;
        }
    }

    public class PayrollSystem
    {
        private List<BaseEmployee> employees = new List<BaseEmployee>();

        public void AddEmployee(BaseEmployee employee)
        {
            employees.Add(employee);
        }

        public List<BaseEmployee> GetEmployees()
        {
            return employees;
        }

        public decimal CalculateTotalPayroll()
        {
            return employees.Sum(e => e.CalculateSalary());
        }
    }
}
