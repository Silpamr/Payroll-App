﻿using System;
using PayrollBackend;

class Program
{
    static void Main()
    {
        PayrollSystem payroll = new PayrollSystem();
        bool running = true;

        while (running)
        {
            Console.WriteLine("\n--- Payroll System ---");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Display Employees");
            Console.WriteLine("3. Calculate Total Payroll");
            Console.WriteLine("4. Exit");
            Console.Write("Choose an option: ");
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.Write("Enter Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Role (Manager/Developer/Intern): ");
                    string role = Console.ReadLine();
                    BaseEmployee employee = role switch
                    {
                        "Manager" => new Manager { Id = new Random().Next(1000, 9999), Name = name, BasicPay = 5000, Allowances = 1000, Bonus = 2000 },
                        "Developer" => new Developer { Id = new Random().Next(1000, 9999), Name = name, BasicPay = 4000, Allowances = 800 },
                        "Intern" => new Intern { Id = new Random().Next(1000, 9999), Name = name, BasicPay = 2000, Allowances = 200, Deduction = 100 },
                        _ => null
                    };
                    if (employee != null)
                    {
                        payroll.AddEmployee(employee);
                        Console.WriteLine("Employee added successfully.");
                    }
                    else
                        Console.WriteLine("Invalid role.");
                    break;
                case 2:
                    foreach (var emp in payroll.GetEmployees())
                        Console.WriteLine($"{emp.Name} ({emp.GetType().Name}) - {emp.CalculateSalary():C}");
                    break;
                case 3:
                    Console.WriteLine($"Total Payroll: {payroll.CalculateTotalPayroll():C}");
                    break;
                case 4:
                    running = false;
                    break;
                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }
        }
    }
}
