﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using PayrollSharedLibrary;


namespace PayrollUIApp
{
    public partial class Form1 : Form
    {
        private PayrollSystem payroll = new PayrollSystem();

        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "Manager", "Developer", "Intern" });

        }
        


        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            int basic = Convert.ToInt32(textBox2.Text);
            int allowance = Convert.ToInt32(textBox3.Text);

            string role = comboBox1.SelectedItem.ToString();
            BaseEmployee employee;
            switch (role)
            {
                case "Manager":
                    employee = new Manager { Id = new Random().Next(1000, 9999), Name = name, BasicPay = basic, Allowances = allowance, Bonus = 2000 };
                    break;
                case "Developer":
                    employee = new Developer { Id = new Random().Next(1000, 9999), Name = name, BasicPay = basic, Allowances = allowance };
                    break;
                case "Intern":
                    employee = new Intern { Id = new Random().Next(1000, 9999), Name = name, BasicPay = basic, Allowances = allowance, Deduction = 100 };
                    break;
                default:
                    employee = null;
                    break;
            }

            if (employee != null)
            {
                payroll.AddEmployee(employee);
                MessageBox.Show("Employee added successfully.");
                textBox1.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = payroll.GetEmployees();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Total Payroll: {payroll.CalculateTotalPayroll():C}");

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView1.Columns["btnCalculateSalary"].Index && e.RowIndex >= 0)
            {
                // Get the selected employee
                var selectedEmployee = dataGridView1.Rows[e.RowIndex].DataBoundItem as BaseEmployee;

                if (selectedEmployee != null)
                {
                    // Calculate the salary
                    decimal salary = selectedEmployee.CalculateSalary();

                    // Show the salary in a MessageBox or display it in the UI
                    MessageBox.Show($"Salary of {selectedEmployee.Name}: {salary:C}", "Salary Calculation");
                }
            }
        }
        

      

    }
}
